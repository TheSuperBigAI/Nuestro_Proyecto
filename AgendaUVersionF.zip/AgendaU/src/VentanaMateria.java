/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class VentanaMateria extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaMateria.class.getName());

    /**
     * Creates new form VentanaMateria
     */
    private final MateriaDAO materiaDAO = new MateriaDAO();
    private java.util.List<Materia> materias = new java.util.ArrayList<>();

    public VentanaMateria() {
        initComponents();
        configurar();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableM = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtprofesor = new javax.swing.JTextField();
        BtnAgregar = new javax.swing.JButton();
        Btneditar = new javax.swing.JButton();
        Btneliminar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(807, 600));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 255));

        jLabel1.setFont(new java.awt.Font("Roboto Black", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Materias");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(719, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 40));

        TableM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TableM);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 730, 290));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 810, 10));

        jLabel2.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Nombre");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 60, -1));

        txtnombre.setBackground(new java.awt.Color(255, 255, 255));
        txtnombre.setForeground(new java.awt.Color(0, 0, 0));
        txtnombre.setText("Nombre de la materia");
        jPanel1.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 250, 30));

        jLabel3.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Profesor");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 460, 90, -1));

        txtprofesor.setBackground(new java.awt.Color(255, 255, 255));
        txtprofesor.setFont(new java.awt.Font("Roboto Black", 0, 12)); // NOI18N
        txtprofesor.setForeground(new java.awt.Color(0, 0, 0));
        txtprofesor.setText("Nombre del profesor");
        jPanel1.add(txtprofesor, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 480, 280, 30));

        BtnAgregar.setBackground(new java.awt.Color(51, 51, 255));
        BtnAgregar.setFont(new java.awt.Font("Roboto Black", 0, 12)); // NOI18N
        BtnAgregar.setForeground(new java.awt.Color(255, 255, 255));
        BtnAgregar.setText("Agregar");
        jPanel1.add(BtnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 480, 90, 30));

        Btneditar.setBackground(new java.awt.Color(255, 255, 255));
        Btneditar.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        Btneditar.setForeground(new java.awt.Color(0, 0, 0));
        Btneditar.setText("Editar");
        jPanel1.add(Btneditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 80, 30));

        Btneliminar.setBackground(new java.awt.Color(255, 255, 255));
        Btneliminar.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        Btneliminar.setForeground(new java.awt.Color(0, 0, 0));
        Btneliminar.setText("Eliminar");
        jPanel1.add(Btneliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 520, 90, 30));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Cerrar");
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 520, 80, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    private void configurar() {
        // Cerrar esta ventana no debe cerrar toda la aplicación
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        TableM.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {}, new String[] {"Nombre", "Profesor"}) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        });
        TableM.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        TableM.setRowHeight(28);
        txtnombre.putClientProperty("JTextField.placeholderText", "Nombre de la materia");
        txtprofesor.putClientProperty("JTextField.placeholderText", "Nombre del profesor");

        // Al elegir una fila, sus datos pasan al formulario para poder editarlos
        TableM.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) cargarFormulario();
        });
        BtnAgregar.addActionListener(e -> agregar());
        Btneditar.addActionListener(e -> editar());
        Btneliminar.addActionListener(e -> eliminar());
        jButton1.addActionListener(e -> dispose());      // botón Cerrar
        setLocationRelativeTo(null);
        cargarTabla();
    }

    private void cargarTabla() {
        try {
            materias = materiaDAO.listar(Sesion.getIdUsuario());
        } catch (java.sql.SQLException ex) {
            Conexion.mostrarError(this, ex);
            return;
        }
        javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) TableM.getModel();
        modelo.setRowCount(0);
        for (Materia m : materias) {
            modelo.addRow(new Object[] { m.getNombre(), m.getProfesor() == null ? "" : m.getProfesor() });
        }
        limpiarFormulario();
    }

    private void limpiarFormulario() {
        TableM.clearSelection();
        txtnombre.setText("");
        txtprofesor.setText("");
    }

    private void cargarFormulario() {
        int fila = TableM.getSelectedRow();
        if (fila < 0 || fila >= materias.size()) return;
        Materia m = materias.get(fila);
        txtnombre.setText(m.getNombre());
        txtprofesor.setText(m.getProfesor() == null ? "" : m.getProfesor());
    }

    private void aviso(String mensaje) {
        javax.swing.JOptionPane.showMessageDialog(this, mensaje, "AgendaU",
            javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    /** el nombre es obligatorio; el profesor es opcional. */
    private boolean formularioValido() {
        return Validaciones.campoObligatorio(txtnombre.getText(), "Nombre")
            && Validaciones.longitudMaxima(txtnombre.getText(), 100, "Nombre")
            && Validaciones.longitudMaxima(txtprofesor.getText(), 100, "Profesor");
    }

    
    private void agregar() {
        if (!formularioValido()) return;
        try {
            Materia nueva = new Materia(0, txtnombre.getText(), txtprofesor.getText(), Sesion.getIdUsuario());
            if (materiaDAO.insertar(nueva)) cargarTabla();
            else aviso("Ya tienes una materia con ese nombre.");
        } catch (java.sql.SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    /**modifica la materia seleccionada con lo escrito en el formulario. */
    private void editar() {
        int fila = TableM.getSelectedRow();
        if (fila < 0) { aviso("Selecciona una materia de la tabla para editarla."); return; }
        if (!formularioValido()) return;
        try {
            Materia m = materias.get(fila);
            m.setNombre(txtnombre.getText());
            m.setProfesor(txtprofesor.getText());
            boolean guardada = materiaDAO.actualizar(m);
            cargarTabla();
            if (!guardada) aviso("No se guardó: ya tienes otra materia con ese nombre.");
        } catch (java.sql.SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    /** pide confirmación y avisa cuántas tareas se eliminarán con la materia. */
    private void eliminar() {
        int fila = TableM.getSelectedRow();
        if (fila < 0) { aviso("Selecciona una materia de la tabla para eliminarla."); return; }
        Materia m = materias.get(fila);
        try {
            int tareas = materiaDAO.contarTareas(m.getId(), Sesion.getIdUsuario());
            String mensaje = "¿Eliminar la materia \"" + m.getNombre() + "\"?";
            if (tareas > 0) mensaje += "\nTambién se eliminarán sus " + tareas + " tarea(s).";
            int opcion = javax.swing.JOptionPane.showConfirmDialog(this, mensaje, "Confirmar eliminación",
                javax.swing.JOptionPane.YES_NO_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE);
            if (opcion != javax.swing.JOptionPane.YES_OPTION) return;
            materiaDAO.eliminar(m.getId(), Sesion.getIdUsuario());
            cargarTabla();
        } catch (java.sql.SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAgregar;
    private javax.swing.JButton Btneditar;
    private javax.swing.JButton Btneliminar;
    private javax.swing.JTable TableM;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtprofesor;
    // End of variables declaration//GEN-END:variables
}
