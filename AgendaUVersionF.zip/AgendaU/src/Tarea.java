import java.time.LocalDate;

public class Tarea {

    private int id;
    private String titulo;
    private String descripcion;
    private LocalDate fechaEntrega;
    private boolean completada;
    private int idUsuario;
    private int idMateria;
    private String nombreMateria;   // viene del JOIN con materia; no es columna de tarea

    public Tarea(int id, String titulo, String descripcion, LocalDate fechaEntrega,
                 boolean completada, int idUsuario, int idMateria) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaEntrega = fechaEntrega;
        this.completada = completada;
        this.idUsuario = idUsuario;
        this.idMateria = idMateria;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDate getFechaEntrega() { return fechaEntrega; }
    public void setFechaEntrega(LocalDate fechaEntrega) { this.fechaEntrega = fechaEntrega; }

    public boolean isCompletada() { return completada; }
    public void setCompletada(boolean completada) { this.completada = completada; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public int getIdMateria() { return idMateria; }
    public void setIdMateria(int idMateria) { this.idMateria = idMateria; }

    public String getNombreMateria() { return nombreMateria; }
    public void setNombreMateria(String nombreMateria) { this.nombreMateria = nombreMateria; }

    
    public String getEstadoVisual() {
        if (completada) return "Completada";
        LocalDate hoy = LocalDate.now();
        if (fechaEntrega.isBefore(hoy)) return "Atrasada";
        if (!fechaEntrega.isAfter(hoy.plusDays(3))) return "Próxima";
        return "Pendiente";
    }
}
