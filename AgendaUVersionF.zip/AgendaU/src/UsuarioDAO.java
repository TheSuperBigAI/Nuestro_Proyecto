import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

/**
 * Consultas de la tabla usuario. Todas usan PreparedStatement y
 * lanzan SQLException: la ventana la atrapa con Conexion.mostrarError(...).
 */
public class UsuarioDAO {

    
    private static String normalizar(String correo) {
        return correo.trim().toLowerCase();
    }

    public boolean existeCorreo(String correo) throws SQLException {
        String sql = "SELECT 1 FROM usuario WHERE correo = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, normalizar(correo));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Crea el usuario guardando la contraseña como hash.
     * Devuelve false si el correo ya existe; el UNIQUE de la base de
     * datos lo garantiza aunque dos personas lo intenten a la vez.
     */
    public boolean registrar(String nombre, String correo, String contrasenaPlana) throws SQLException {
        String sql = "INSERT INTO usuario (nombre, correo, contrasena) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre.trim());
            ps.setString(2, normalizar(correo));
            ps.setString(3, HashUtil.hashear(contrasenaPlana));
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false;   // correo repetido
        }
    }

    /**
     * Valida las credenciales. Devuelve el Usuario si son correctas
     * o null si el correo no existe o la contraseña no coincide. Se responde
     * igual en ambos casos para no revelar qué correos están registrados.
     */
    public Usuario iniciarSesion(String correo, String contrasenaPlana) throws SQLException {
        String sql = "SELECT id, nombre, correo, contrasena FROM usuario WHERE correo = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, normalizar(correo));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && HashUtil.verificar(contrasenaPlana, rs.getString("contrasena"))) {
                    return new Usuario(rs.getInt("id"), rs.getString("nombre"),
                                       rs.getString("correo"), rs.getString("contrasena"));
                }
                return null;
            }
        }
    }
}
