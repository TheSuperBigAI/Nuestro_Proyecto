import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

/**
 * Consultas de la tabla materia. Todas filtran por id_usuario: un usuario
 * nunca puede ver ni tocar las materias de otro.
 */
public class MateriaDAO {

    /** Materias del usuario, en orden alfabético. Sirve para la tabla y para el desplegable. */
    public List<Materia> listar(int idUsuario) throws SQLException {
        String sql = "SELECT id, nombre, profesor, id_usuario FROM materia "
                   + "WHERE id_usuario = ? ORDER BY nombre";
        List<Materia> lista = new ArrayList<>();
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Materia(rs.getInt("id"), rs.getString("nombre"),
                                          rs.getString("profesor"), rs.getInt("id_usuario")));
                }
            }
        }
        return lista;
    }

    /** Devuelve false si el usuario ya tiene una materia con ese nombre. */
    public boolean insertar(Materia m) throws SQLException {
        String sql = "INSERT INTO materia (nombre, profesor, id_usuario) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getNombre().trim());
            ps.setString(2, textoOpcional(m.getProfesor()));
            ps.setInt(3, m.getIdUsuario());
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false;   // nombre repetido
        }
    }

    /**  Devuelve false si no existe, no es del usuario, o el nombre ya está en uso. */
    public boolean actualizar(Materia m) throws SQLException {
        String sql = "UPDATE materia SET nombre = ?, profesor = ? WHERE id = ? AND id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getNombre().trim());
            ps.setString(2, textoOpcional(m.getProfesor()));
            ps.setInt(3, m.getId());
            ps.setInt(4, m.getIdUsuario());
            return ps.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false;
        }
    }

    /**  La base de datos borra también las tareas de la materia (ON DELETE CASCADE). */
    public boolean eliminar(int idMateria, int idUsuario) throws SQLException {
        String sql = "DELETE FROM materia WHERE id = ? AND id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMateria);
            ps.setInt(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    /** Para avisar en la confirmación: "Esta materia tiene N tareas que también se eliminarán". */
    public int contarTareas(int idMateria, int idUsuario) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tarea WHERE id_materia = ? AND id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMateria);
            ps.setInt(2, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    private static String textoOpcional(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }
}
