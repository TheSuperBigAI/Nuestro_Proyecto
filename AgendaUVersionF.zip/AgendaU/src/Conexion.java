import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Conexion {

    
    private static final String URL =
        "jdbc:mysql://localhost:3306/agendau?useUnicode=true&characterEncoding=UTF-8";
    private static final String USUARIO = "root";
    private static final String CLAVE = "";   // WampServer trae root sin contraseña

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }

    /**
     * Mensaje estándar cuando falla la base de datos (RNF-05): la aplicación
     * no se cierra y el usuario sabe qué pasó. Se usa en el catch de cada ventana:
     *
     *     catch (SQLException ex) { Conexion.mostrarError(this, ex); }
     */
    public static void mostrarError(Component padre, SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(padre,
            "No se pudo completar la operación con la base de datos.\n"
            + "Verifica que WampServer esté encendido (ícono verde).",
            "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }
}
