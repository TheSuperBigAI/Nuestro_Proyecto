import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {

    public static void main(String[] args) {
        activarEstiloModerno();
        SwingUtilities.invokeLater(() -> {
            VentanaSesion login = new VentanaSesion();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        });
    }

    
    private static void activarEstiloModerno() {
        try {
            Class.forName("com.formdev.flatlaf.FlatLightLaf").getMethod("setup").invoke(null);
            UIManager.put("Button.arc", 6);
        } catch (Exception | LinkageError e) {
            System.out.println("FlatLaf no disponible: se usa el estilo por defecto.");
        }
    }
}
