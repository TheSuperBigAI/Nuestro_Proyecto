/**
 * Guarda al usuario que inició sesión. Todas las ventanas y los DAO leen de
 * aquí el id para mostrar solo los datos de ese usuario (RF-05, RNF-08).
 */
public class Sesion {

    private static Usuario usuarioActual;

    public static void iniciar(Usuario usuario) { usuarioActual = usuario; }

    public static void cerrar() { usuarioActual = null; }

    public static boolean haySesion() { return usuarioActual != null; }

    public static Usuario getUsuario() { return usuarioActual; }

    public static int getIdUsuario() { return usuarioActual.getId(); }
}
