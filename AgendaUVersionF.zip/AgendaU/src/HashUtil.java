import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Guarda contraseñas como HASH con sal (PBKDF2 con HMAC-SHA256), sin librerías
 * externas: viene incluido en Java. Cumple el RNF de seguridad: la contraseña
 * nunca se guarda en texto plano.
 *
 * Formato guardado en la columna usuario.contrasena:
 *     pbkdf2$<iteraciones>$<sal en Base64>$<hash en Base64>
 * La sal es distinta para cada usuario, así dos contraseñas iguales producen
 * hashes distintos.
 */
public class HashUtil {

    private static final int ITERACIONES = 120_000;
    private static final int BYTES_SAL = 16;
    private static final int BITS_HASH = 256;
    private static final SecureRandom ALEATORIO = new SecureRandom();

    /** Convierte la contraseña en el texto que se guarda en la base de datos. */
    public static String hashear(String contrasena) {
        byte[] sal = new byte[BYTES_SAL];
        ALEATORIO.nextBytes(sal);
        byte[] hash = derivar(contrasena, sal, ITERACIONES);
        return "pbkdf2$" + ITERACIONES + "$"
             + Base64.getEncoder().encodeToString(sal) + "$"
             + Base64.getEncoder().encodeToString(hash);
    }

    /** Compara la contraseña escrita en el login con el texto guardado. */
    public static boolean verificar(String contrasena, String guardado) {
        if (contrasena == null || guardado == null) return false;
        String[] partes = guardado.split("\\$");
        if (partes.length != 4 || !partes[0].equals("pbkdf2")) return false;
        try {
            int iteraciones = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            byte[] obtenido = derivar(contrasena, sal, iteraciones);
            return MessageDigest.isEqual(esperado, obtenido);   // comparación en tiempo constante
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] derivar(String contrasena, byte[] sal, int iteraciones) {
        try {
            PBEKeySpec spec = new PBEKeySpec(contrasena.toCharArray(), sal, iteraciones, BITS_HASH);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException("No se pudo calcular el hash", e);
        }
    }
}
