import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 * Validaciones de los formularios de AgendaU.
 *
 * Regla única: todos los métodos devuelven true cuando el dato es VÁLIDO.
 * Si el dato no es válido, muestran un mensaje y devuelven false (o null
 * en fechaValida), así que en las ventanas se usan siempre igual:
 *
 *    
 */
public class Validaciones {

    //  "Mínimo 6 caracteres" de VentanaCuenta.
    public static final int MIN_CONTRASENA = 6;

    private static final Pattern CORREO =
        Pattern.compile("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$");

    // Letras de cualquier idioma, separadas por espacio, apóstrofo o guion.
    private static final Pattern NOMBRE_PERSONA =
        Pattern.compile("^\\p{L}+([ '\\-]\\p{L}+)*$");

    // STRICT rechaza fechas que no existen, como 31/02/2026.
    private static final DateTimeFormatter FORMATO_FECHA =
        DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    /** Muestra el aviso y devuelve false, para poder escribir: return advertir(...). */
    private static boolean advertir(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.WARNING_MESSAGE);
        return false;
    }

    /** El campo no puede estar vacío ni tener solo espacios. */
    public static boolean campoObligatorio(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            return advertir("Campo requerido",
                "El campo \"" + nombreCampo + "\" no puede estar vacío.");
        }
        return true;
    }

    /** El texto no puede superar el largo de su columna en MySQL (título 150, nombre 100...). */
    public static boolean longitudMaxima(String valor, int max, String nombreCampo) {
        if (valor != null && valor.trim().length() > max) {
            return advertir("Texto demasiado largo",
                "El campo \"" + nombreCampo + "\" admite máximo " + max + " caracteres.");
        }
        return true;
    }

    public static boolean correoValido(String correo) {
        if (correo == null || !CORREO.matcher(correo.trim()).matches()) {
            return advertir("Correo inválido",
                "El correo no tiene un formato válido.\nEjemplo: usuario@dominio.com");
        }
        return true;
    }

    /** Usar con String.valueOf(passwordField.getPassword()). */
    public static boolean contrasenaValida(String contrasena) {
        if (contrasena == null || contrasena.length() < MIN_CONTRASENA) {
            return advertir("Contraseña débil",
                "La contraseña debe tener al menos " + MIN_CONTRASENA + " caracteres.");
        }
        return true;
    }

    public static boolean contrasenasIguales(String contrasena, String confirmacion) {
        if (contrasena == null || !contrasena.equals(confirmacion)) {
            return advertir("Contraseñas distintas",
                "La contraseña y su confirmación no coinciden.");
        }
        return true;
    }

    /**
     * Solo para NOMBRES DE PERSONA (usuario, profesor). No usarlo en el nombre de
     * una materia: "Cálculo 2" o "Ingeniería de Software I" tienen números.
     */
    public static boolean nombrePersonaValido(String valor, String nombreCampo) {
        if (valor == null || !NOMBRE_PERSONA.matcher(valor.trim()).matches()) {
            return advertir("Formato inválido",
                "El campo \"" + nombreCampo + "\" solo debe contener letras y espacios.");
        }
        return true;
    }

    /**
     * Convierte "dd/mm/aaaa" a LocalDate. Si no es una fecha real muestra el
     * mensaje y devuelve null; si es válida, devuelve la fecha lista para usar.
     */
    public static LocalDate fechaValida(String texto, String nombreCampo) {
        try {
            return LocalDate.parse(texto.trim(), FORMATO_FECHA);
        } catch (DateTimeParseException | NullPointerException e) {
            advertir("Fecha inválida",
                "El campo \"" + nombreCampo + "\" debe ser una fecha real con el formato dd/mm/aaaa.\n"
                + "Ejemplo: 25/11/2026");
            return null;
        }
    }

    /** Al CREAR una tarea no se aceptan fechas anteriores a hoy. Al editar no se usa. */
    public static boolean fechaNoPasada(LocalDate fecha, String nombreCampo) {
        if (fecha.isBefore(LocalDate.now())) {
            return advertir("Fecha pasada",
                "El campo \"" + nombreCampo + "\" no puede ser anterior a hoy.");
        }
        return true;
    }

    /** Verifica que haya algo elegido en un JComboBox (por ejemplo, la materia). */
    public static boolean seleccionObligatoria(JComboBox<?> combo, String nombreCampo) {
        if (combo.getSelectedIndex() < 0) {
            return advertir("Selección requerida",
                "Debes elegir una opción en \"" + nombreCampo + "\".");
        }
        return true;
    }
}
