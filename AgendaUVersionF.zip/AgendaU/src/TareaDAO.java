import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Consultas de la tabla tarea. Todas filtran por id_usuario, y al guardar
 * comprueban que la materia elegida sea del mismo usuario (RNF-08).
 */
public class TareaDAO {

    /**
     * RF-10. Devuelve false si la materia no existe o no pertenece al usuario.
     * La materia se valida dentro del mismo INSERT, en una sola consulta.
     */
    public boolean insertar(Tarea t) throws SQLException {
        String sql = "INSERT INTO tarea (titulo, descripcion, fecha_entrega, completada, id_usuario, id_materia) "
                   + "SELECT ?, ?, ?, 0, ?, m.id FROM materia m WHERE m.id = ? AND m.id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getTitulo().trim());
            ps.setString(2, textoOpcional(t.getDescripcion()));
            ps.setDate(3, Date.valueOf(t.getFechaEntrega()));
            ps.setInt(4, t.getIdUsuario());
            ps.setInt(5, t.getIdMateria());
            ps.setInt(6, t.getIdUsuario());
            return ps.executeUpdate() > 0;
        }
    }

    /** Devuelve false si la tarea o la materia no son del usuario. */
    public boolean actualizar(Tarea t) throws SQLException {
        String sql = "UPDATE tarea SET titulo = ?, descripcion = ?, fecha_entrega = ?, id_materia = ? "
                   + "WHERE id = ? AND id_usuario = ? "
                   + "AND ? IN (SELECT id FROM materia WHERE id_usuario = ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getTitulo().trim());
            ps.setString(2, textoOpcional(t.getDescripcion()));
            ps.setDate(3, Date.valueOf(t.getFechaEntrega()));
            ps.setInt(4, t.getIdMateria());
            ps.setInt(5, t.getId());
            ps.setInt(6, t.getIdUsuario());
            ps.setInt(7, t.getIdMateria());
            ps.setInt(8, t.getIdUsuario());
            return ps.executeUpdate() > 0;
        }
    }

    /** RF-15 (la confirmación se pide en la ventana, antes de llamar a este método). */
    public boolean eliminar(int idTarea, int idUsuario) throws SQLException {
        String sql = "DELETE FROM tarea WHERE id = ? AND id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idTarea);
            ps.setInt(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    /**  Después de esto la tarea deja de salir en la lista de pendientes. */
    public boolean marcarCompletada(int idTarea, int idUsuario) throws SQLException {
        String sql = "UPDATE tarea SET completada = 1 WHERE id = ? AND id_usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idTarea);
            ps.setInt(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    /**  pendientes del usuario, de la fecha más cercana a la más lejana. */
    public List<Tarea> listarPendientes(int idUsuario) throws SQLException {
        return listarPendientes(idUsuario, null, null);
    }

    /**
     * 
     * @param idMateria si no es null, solo las tareas de esa materia (filtro)
     * @param texto     si no es null ni vacío, solo las que contengan ese texto en el
     *                  título (búsqueda parcial, sin distinguir mayúsculas)
     */
    public List<Tarea> listarPendientes(int idUsuario, Integer idMateria, String texto) throws SQLException {
        StringBuilder sql = new StringBuilder(
            "SELECT t.id, t.titulo, t.descripcion, t.fecha_entrega, t.completada, "
          + "t.id_usuario, t.id_materia, m.nombre AS materia "
          + "FROM tarea t JOIN materia m ON m.id = t.id_materia "
          + "WHERE t.id_usuario = ? AND t.completada = 0 ");
        boolean porMateria = idMateria != null;
        boolean porTexto = texto != null && !texto.trim().isEmpty();
        if (porMateria) sql.append("AND t.id_materia = ? ");
        if (porTexto)   sql.append("AND LOWER(t.titulo) LIKE ? ESCAPE '!' ");
        sql.append("ORDER BY t.fecha_entrega ASC, t.id ASC");

        List<Tarea> lista = new ArrayList<>();
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            ps.setInt(i++, idUsuario);
            if (porMateria) ps.setInt(i++, idMateria);
            if (porTexto) {
                String limpio = texto.trim().toLowerCase()
                                    .replace("!", "!!").replace("%", "!%").replace("_", "!_");
                ps.setString(i++, "%" + limpio + "%");
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Tarea t = new Tarea(rs.getInt("id"), rs.getString("titulo"), rs.getString("descripcion"),
                        rs.getDate("fecha_entrega").toLocalDate(), rs.getBoolean("completada"),
                        rs.getInt("id_usuario"), rs.getInt("id_materia"));
                    t.setNombreMateria(rs.getString("materia"));
                    lista.add(t);
                }
            }
        }
        return lista;
    }

    /**
     *  para la barra inferior: { pendientes, atrasadas, próximas }.
     * Usa getEstadoVisual() para que los números coincidan con lo que muestra la tabla.
     */
    public int[] contarResumen(int idUsuario) throws SQLException {
        int atrasadas = 0, proximas = 0;
        List<Tarea> pendientes = listarPendientes(idUsuario);
        for (Tarea t : pendientes) {
            String estado = t.getEstadoVisual();
            if (estado.equals("Atrasada")) atrasadas++;
            else if (estado.equals("Próxima")) proximas++;
        }
        return new int[] { pendientes.size(), atrasadas, proximas };
    }

    private static String textoOpcional(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }
}
