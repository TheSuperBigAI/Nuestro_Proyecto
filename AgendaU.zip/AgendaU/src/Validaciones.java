/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javax.swing.*;

public class Validaciones {
    // Verifica que un campo de texto no este vacio ni en blanco
    public static boolean campoVacio(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "El campo \"" + nombreCampo + "\" no puede estar vacio.\nPor favor, completa todos los campos.",
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return true;
        }
        return false;
    }
    
    // Verifica que el correo tenga formato basico valido
    public static boolean correoValido(String correo) {
        if (!correo.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(null,
                "El correo electronico no tiene un formato valido.\nEjemplo: usuario@dominio.com",
                "Correo invalido", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
    
    // Verifica que la contraseña tenga al menos 6 caracteres
    public static boolean contrasenaValida(String contrasena) {
        if (contrasena.length() < 6) {
            JOptionPane.showMessageDialog(null,
                "La contraseña debe tener al menos 6 caracteres.",
                "Contraseña debil", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
    
      // Verifica que un campo de texto tenga solo letras y espacios
    public static boolean soloLetras(String valor, String nombreCampo) {
        if (!valor.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            JOptionPane.showMessageDialog(null,
                "El campo \"" + nombreCampo + "\" solo debe contener letras.",
                "Formato invalido", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
